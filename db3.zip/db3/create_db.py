import sqlite3

# create db conenction and cursor
connection = sqlite3.connect('careers.db')
cursor = connection.cursor()

createIntrests = """CREATE TABLE IF NOT EXISTS Interests (
  abbrv text PRIMARY KEY,
  descr text NOT NULL
);"""

loadIntrests = """
INSERT INTO interests VALUES 
  ('android' , 'Android Development'),
  ('app' , 'Mobile App Development'),
  ('aws' , 'Amazon Web Service'),
  ('cloud' , 'Cloud Computing'),
  ('cyber' , 'Cyber Security'),
  ('db' , 'Databases'),
  ('dba' , 'Database Administrator'),
  ('edu' , 'Education'),
  ('java' , 'Java'),
  ('kotlin' , 'Kotlin'),
  ('mysql' , 'MySQL'),
  ('postgres' , 'Postgresql'),
  ('python' , 'Python'),
  ('software' , 'Software Development'),
  ('sql' , 'SQL'),
  ('web' , 'Web Development');
  """


createStudents = """
CREATE TABLE IF NOT EXISTS Students (
  email TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  major TEXT NOT NULL,
  graduation TEXT NOT NULL
  );  
"""

loadStudents = """
INSERT INTO Students VALUES 
  ('eastmanv@msudenver.edu', 'Virginia Eastman', 'cs', 'Spring 2022'),
  ('gilbertb@msudenver.edu', 'Barbara Gilbert', 'cs', 'Fall 2023'),
  ('zachariasr@msudenver.edu', 'Robert Zacharias', 'cs', 'Spring 2023');
"""


createEmploy = """
CREATE TABLE IF NOT EXISTS Employers (
  id INT PRIMARY KEY,
  "name" TEXT NOT NULL,
  "size" INT NOT NULL,
  location TEXT NOT NULL,
  forprofit BOOLEAN NOT NULL,
  govern BOOLEAN NOT NULL
);

"""

loadEmploy = """
INSERT INTO Employers VALUES
  (101, 'Wonka Industries', 350, 'Lakewood, CO', true, false),
  (202, 'Cheers Agency', 1000, 'Denver, CO', false, true),
  (303, 'Dominate the World', 5, 'Golden, CO', true, false),
  (404, 'Stingers Org', 212, 'Denver, CO', false, false),
  (505, 'Easy Peasy', 1, 'Littleton, CO', true, false);
"""
createStudentsInterests = """
CREATE TABLE IF NOT EXISTS StudentInterests (
    numID INT  PRIMARY KEY,
    email TEXT,
    abbrv TEXT,
    FOREIGN KEY (email) REFERENCES Students (email),
    FOREIGN KEY (abbrv) REFERENCES Intrests (abbrv)
);
"""

loadStudentInterests = """
    INSERT INTO StudentInterests VALUES
    (1,'eastmanv@msudenver.edu', 'cloud'),
    (2,'eastmanv@msudenver.edu', 'db'),
    (3,'eastmanv@msudenver.edu', 'java'),
    (4,'eastmanv@msudenver.edu', 'mysql'),
    (5,'eastmanv@msudenver.edu', 'sql'),
    (6,'gilbertb@msudenver.edu', 'db'),
    (7,'gilbertb@msudenver.edu', 'python'),
    (8,'gilbertb@msudenver.edu', 'sql'),
    (9,'zachariasr@msudenver.edu', 'cloud'),
    (10,'zachariasr@msudenver.edu', 'edu'),
    (11,'zachariasr@msudenver.edu', 'web')
"""

createEmpInterests = """
CREATE TABLE IF NOT EXISTS EmployerInterests (
    numID INT PRIMARY KEY,
    id INT,
    abbrv TEXT,
    FOREIGN KEY (id) REFERENCES Employers (id),
    FOREIGN KEY (abbrv) REFERENCES Intrests (abbrv)
);
"""

loadEmpInterests = """
    INSERT INTO EmployerInterests VALUES
    (1,101, 'cloud'),
    (2,101, 'dba'),
    (3,101, 'java'),
    (4,101,'mysql'),
    (5,101, 'sql'),
    (6,202, 'aws'),
    (7,202, 'cloud'),
    (8,202, 'python'),
    (9,202, 'sql'),
    (10,303, 'cloud'),
    (11,303, 'cyber'),
    (12,303, 'java'),
    (13,303, 'web'),
    (14,404, 'postgres'),
    (15,404, 'python'),
    (16,404, 'sql'),
    (17,505, 'java');
"""



if __name__ == '__main__':
    ## execute creation of table Intrests
    cursor.execute(createIntrests)

    # execute loading of values into table Intrests
    cursor.execute(loadIntrests)
    connection.commit()
    idata = cursor.execute("""
    SELECT * FROM Interests;
    """)

    print(idata.fetchall())



    # execute creation of table Students
    cursor.execute(createStudents)

    # execute loading of values into Students
    cursor.execute(loadStudents)
    connection.commit()

    data = cursor.execute("""
    SELECT * FROM Students;
     """)

    print(data.fetchall())

    cursor.execute(createEmploy)
    cursor.execute(loadEmploy)
    connection.commit()

    empData = cursor.execute("""
        SELECT * FROM Employers;
         """)

    print(empData.fetchall())

    cursor.execute(createStudentsInterests)
    cursor.execute(loadStudentInterests)
    connection.commit()

    SIData = cursor.execute("""
            SELECT * FROM StudentInterests;
             """)

    print(SIData.fetchall())

    cursor.execute(createEmpInterests)
    cursor.execute(loadEmpInterests)
    connection.commit()

    empIata = cursor.execute("""
                SELECT * FROM EmployerInterests;
                 """)

    print(empIata.fetchall())











'''
CS3810 - Principles of Database Systems - Spring 2022
Instructor: Thyago Mota
Student Names: Josh Gray, Anna Watson
Description: creates Interest entity and allows listing of all interests
'''


from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer, create_engine
from sqlalchemy.orm import sessionmaker, relationship

Base = declarative_base()


# TODO: finish the object-relational mapping
class Interest(Base):
    __tablename__ = "Interests"
    id = Column('abbrv', String, primary_key=True)
    descr = Column('descr', String)

    student_interest_relationship = relationship('Student', secondary='StudentInterest')


if __name__ == "__main__":

    # db connection and session creation
    db_string = "sqlite:///careers.db"
    db = create_engine(db_string, echo=True)
    Session = sessionmaker(bind=db)
    session = Session(bind=db)

    # TODO: list all interests

    interestsResult = session.query(Interest).all()

    for row in interestsResult:
        print(row.id, row.descr)

    session.close()

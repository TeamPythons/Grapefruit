'''
CS3810 - Principles of Database Systems - Spring 2022
Instructor: Thyago Mota
Student Names:Josh Gray Anna Watson
Description: creates a Student entity with a 1-many mapping to StudentInterest and allows listing of all students
'''

from interest import Interest
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, String, Integer, create_engine, ForeignKey
from sqlalchemy.orm import sessionmaker, relationship

Base = declarative_base()


# TODO: finish the object-relational mapping
class Student(Base):
    __tablename__ = "Students"
    email = Column('email', String, primary_key=True)
    name = Column('name', String)
    major = Column('major', String)
    graduation = Column('graduation', String)

    student_interest_relationship = relationship('Interests', secondary='StudentInterest')


# TODO: finish the object-relational mapping
class StudentInterest(Base):
    __tablename__ = 'StudentInterests'
    email = Column(String, ForeignKey('Students.email'), primary_key=True)
    abbrv = Column( String, ForeignKey('interests.abbrv'),primary_key=True)

if __name__ == "__main__":

    # db connection and session creation
    db_string = "sqlite:///careers.db"
    db = create_engine(db_string, echo=True)
    Session = sessionmaker(bind=db)
    session = Session(bind=db)

    # TODO: list all students and intrests

    studentResult = session.query(Student, Interest).filter(StudentInterest.email == Student.email, StudentInterest.abbr == Interest.abbr)

    for row in studentResult:
        print(row.email, row.name)

    session.close()
